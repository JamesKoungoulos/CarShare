def frat_analysis_frequency(email):

    sql_id      = """SELECT memberno
                     FROM Member
                     WHERE email = %s"""

    memid = str(cursor.execute(sql_id, (email)))

    now = datetime.datetime.now()
    current_date = datetime.date.today()


    sql_booking = """SELECT MIN(whenBooked)
                     FROM Booking
                     WHERE madeby = %s"""

    earliest_booking = cursor.execute(sql_booking, (memid))

    sql_stat_booking = """SELECT stat_nrOfBookings
                          FROM Member
                          WHERE email = %s"""

    bookings_total = cursor.execute(sql_stat_booking, (email))

    time_period = (current_date - earliest_booking)

    frequency = float(time_period.days)/bookings_total

    #Add new column with default value to Member TABLE
    #ALTER TABLE Member
    #ADD frequency FLOAT NOT NULL DEFAULT 0;

    #Update the frequency column with the new frequency value.
    #sql_frequency_update = """UPDATE Member
    #                SET frequency = %s
    #                WHERE email = %s"""

    #execute.cursor(sql_frequency_update, (frequency, email))
    #connection.commit()

    sql_frequency = """SELECT frequency
                       FROM Member
                       ASC"""

    cursor.execute(sql_frequency)

    frequency_list = list(cursor.fetchall())

    total_frequency = len(frequency_list)

    frequency_counter = 0

    while float(frequency_list[i]) != frequency:
        frequency_counter = frequency_counter + 1

    frequency_result = 0

    if(frequency_counter/frequency_list < 0.2):
        frequency_result = 1

    elif(frequency_counter/frequency_list < 0.4):
        frequency_result = 2

    elif(frequency_counter/frequency_list < 0.6):
        frequency_result = 3

    elif(frequency_counter/frequency_list < 0.8):
        frequency_result = 4

    else:
        frequency_result = 5

    return frequency_result

def frat_analysis_recency(email):

    sql_id      = """SELECT memberno
                     FROM Member
                     WHERE email = %s"""

    memid = str(cursor.execute(sql_id, (email)))

    sql_recent = """SELECT MAX(whenBooked)
                    FROM Booking
                    WHERE madeby = %s"""

    sql_all_recent = """SELECT MAX(whenbooked)
                        FROM Booking
                        GROUP BY madeby
                        ASC"""

    recency = cursor.execute(sql_recent, (memid))

    cursor.execute(sql_all_recent)

    recency_list = list(cursor.fetchall)

    total_recency = len(recency_list)

    recency_counter = 0

    while float(recency_list[i]) != recency:
        recency_counter = recency_counter + 1

    recency_result = 0

    if(recency_counter/recency_list < 0.2):
        recency_result = 1

    elif(recency_counter/recency_list < 0.4):
        recency_result = 2

    elif(recency_counter/recency_list < 0.6):
        recency_result = 3

    elif(recency_counter/recency_list < 0.8):
        recency_result = 4

    else:
        recency_result = 5

    return recency_result

def frat_analysis_amount(email):

   sql_id      = """SELECT memberno
                     FROM Member
                     WHERE email = %s"""

    memid = str(cursor.execute(sql_id, (email)))

    sql_stat_payment = """SELECT stat_sumPayments
                          FROM Member
                          WHERE email = %s"""

    payment_total = cursor.execute(sql_stat_payment, (email))

    amount = float(30 * (payment_total/int(time_period.days)))

    #Add new column with default value to Member TABLE
    #ALTER TABLE Member
    #ADD average_amount FLOAT NOT NULL DEFAULT 0;

    #Update the frequency column with the new frequency value.
    #sql_average_update = """UPDATE Member
    #                SET average_amount = %s
    #                WHERE email = %s"""

    #execute.cursor(sql_average_update, (amount, email))
    #connection.commit()

    sql_average = """SELECT average_amount
                       FROM Member
                       ASC"""

    cursor.execute(sql_average)

    average_list = list(cursor.fetchall())

    total_average = len(average_list)

    average_counter = 0

    while float(average_list[i]) != amount:
        average_counter = average_counter + 1

    average_result = 0

    if(average_counter/average_list < 0.2):
        average_result = 1

    elif(average_counter/average_list < 0.4):
        average_result = 2

    elif(average_counter/average_list < 0.6):
        average_result = 3

    elif(average_counter/average_list < 0.8):
        average_result = 4

    else:
        average_result = 5

    return average_result

def frat_analysis_type(email):

    sql_id = """SELECT memberno
                FROM Member
                WHERE email = %s"""

     memid = str(cursor.execute(sql_id, (email)))

     sql_dates = """SELECT whenBooked
                    FROM Booking
                    WHERE madeby = %s"""

     cursor.execute(sql_dates, (memid))

     dates_list = list(cursor.fetchall())

     weekday_count = 0
     weekend_count = 0
     count = 0

     while count < len(dates_list):
        if(dates_list[count].weekday() < 5):
            weekday_count = weekday_count + 1

        elif(dates_list[count].weekday() => 5):
            weekend_count = weekend_count + 1
       count = count + 1

    if(weekend_count => weekday_count):
        return 'weekend'

    elif(weekday_count > weekend_count):
        return 'weekday'


